# coding: utf-8
# Name:        provider.py
# Author:      Mancuniancol
# Created on:  28.11.2016
# Licence:     GPL v.3: http://www.gnu.org/copyleft/gpl.html
"""
Direct Search Magnetizer module
"""

from urllib import quote_plus

import xbmc
import xbmcgui
import xbmcaddon
from resources.lib.storage import Storage

history = Storage.open('history')
search = xbmcaddon.Addon().getLocalizedString(32000)
new_search = xbmcaddon.Addon().getLocalizedString(32010)

keys = [new_search] + history.keys()

resp = xbmcgui.Dialog().select(search, keys)
print resp
if resp >= 0:
    if resp == 0:
        query = xbmcgui.Dialog().input(search + ":")

    else:
        query = keys[resp]

    if query:
        history[query] = 'x'
        history.sync()
        payload = '?search=general&title=%s' % quote_plus(query)
        xbmc.executebuiltin("XBMC.RunPlugin(plugin://script.module.magnetic%s)" % payload)

history.close()
