Introduction
===================
This script search using magnetic.